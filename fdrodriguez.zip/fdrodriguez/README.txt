Video:
https://www.youtube.com/watch?v=EXtil0StEDs

GitHub Repository:
https://github.com/sicfran774/CS2250-Web-Assignment5

Breath of the Wild API:
https://gadhagod.github.io/Hyrule-Compendium-API/#/